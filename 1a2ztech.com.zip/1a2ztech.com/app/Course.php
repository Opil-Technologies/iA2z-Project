<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    public function allocates()
    {
    	return $this->hasMany('App\Allocate');
    }
}
