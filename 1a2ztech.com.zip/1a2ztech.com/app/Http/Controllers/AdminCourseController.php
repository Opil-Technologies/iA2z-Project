<?php

namespace App\Http\Controllers;

use App\Course;
use App\Allocate;
use App\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Http\Requests\CourseRequest;
use App\Http\Requests\AllocateRequest;

class AdminCourseController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }
    public function index()
    {
    	
    	return view('admin.course.index');
    }
    public function courselist()
    {
        $course = Course::orderBy('id', 'DESC')->get();
        return $course;
    }
    public function store(CourseRequest $request)
    {
    	$course = new Course;
    	$course->course_title = $request->course_title;
    	$course->course_code = $request->course_code;
    	$course->slug = Str::random(5);
    	$course->status = 0;

    	$course->save();
    }
    public function allocate($id)
    {
        $course = Course::whereSlug($id)->firstOrFail();
    	$cid = $id;
    	return view('admin.course.allocate', compact('cid', 'course'));
    }
    public function fetchAllocated($id){
        $allocate = Allocate::whereCourse_id($id)->orderBy('id', 'DESC')->with('department')->get();
        return $allocate;
    }
    public function deleteAllocated($id){
        $delete = Allocate::find($id);
        return $delete->delete();
    }
    public function deleteCourse($id){
        $delete = Course::find($id);
        $dall = Allocate::whereCourse_id($delete->slug)->delete();
        return $delete->delete();
    }
    public function allocate_store(AllocateRequest $request)
    {
    	$allocate = Allocate::firstOrCreate([
            'course_id' => $request->cid,
            'department_id' => $request->dept,
            'level' => $request->level,
            'semester' => $request->semester,
            'course_unit' => $request->course_unit,
            'remark' => $request->remark,
            'status' => 0,

        ]);
    }
    public function fetchDept(){
        $alldept = Department::all();
        return $alldept;
    }
        
}
