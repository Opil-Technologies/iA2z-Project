<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use Illuminate\Http\Request;

class StudentDashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'student', 'biodata']);
    }

    public function index()
    {
    	$detail = User::find(Auth::user()->id);
    	return view('students.dashboard.index', compact('detail'));
    }
}
