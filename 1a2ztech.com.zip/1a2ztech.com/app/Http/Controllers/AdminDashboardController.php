<?php

namespace App\Http\Controllers;

use App\Department;
use Auth;
use App\User;
use App\Profile;
use App\Course;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
	public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }
    public function index()
    {
    	$student = User::all();
    	$dept = Department::all()->count();
    	$profile = Profile::all()->count();
    	$courses = Course::all()->count();

    	return view('admin.dashboard.index', compact('student', 'dept', 'profile', 'courses'));
    }
}
