<?php

namespace App\Http\Controllers;

use Auth;
use App\Profile;
use App\User;
use Illuminate\Http\Request;

class StudentProfileController extends Controller
{
	public function __construct()
    {
        $this->middleware(['auth', 'student']);
    }
    public function index()
    {
    	return view('students.profile.index');
    }
    public function store(Request $request)
    {
    	$biodata = new Profile;
    	$biodata->user_id = Auth::user()->id;
    	$biodata->address = $request->address;
    	$biodata->religion = $request->religion;
    	$biodata->gender = $request->gender;
    	$biodata->dob = $request->dob;
    	$biodata->genotype = $request->genotype;
    	$biodata->status = 0;
    	
    	$biodata->save();
    	
        $status = User::find(Auth::user()->id);
        $status->status = 1;
        
        $status->save();
    	
    	return redirect()->route('student-dashboard');
    }
    public function edit($id)
    {
        $bd = Profile::where('user_id', Auth::user()->id)->first();
        return view('students.profile.edit', compact('bd'));
    }
    public function update(Request $request, $id)
    {
        $bioupdate = Profile::findOrFail($id);
        $bioupdate->address = $request->address;
        $bioupdate->religion = $request->religion;
        $bioupdate->gender = $request->gender;
        $bioupdate->dob = $request->dob;
        $bioupdate->genotype = $request->genotype;
        
        $bioupdate->save();
        
        return redirect()->route('students.profile.edit');
    }
}
