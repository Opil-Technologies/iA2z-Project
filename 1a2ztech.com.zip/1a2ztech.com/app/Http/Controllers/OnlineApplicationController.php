<?php

namespace App\Http\Controllers;

use App\Department;
use App\User;
use App\Http\Requests\Application;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class OnlineApplicationController extends Controller
{
    public function index()
    {
        $dept = Department::all();
    	return view('onlineapplication.application', compact('dept'));
    }
    public function capture(Application $request)
    {
    	$gts = 'GTS-'.rand(1,9).rand(1,9).rand(1,9).rand(1,9).rand(1,9).rand(1,9);
    	session(['ptype' => $request->ptype]);
    	session(['pmode' => $request->pmode]);
    	session(['course' => $request->course]);
    	session(['firstname' => $request->firstname]);
    	session(['lastname' => $request->lastname]);
    	session(['others' => $request->others]);
    	session(['phone' => $request->phone]);
    	session(['email' => $request->email]);
    	session(['app_no' => $gts]);

    	return redirect()->route('preview');
    	
    }
    public function preview()
    {
        if(session()->has('app_no') )
        {
            $ptype = session('ptype');
            $pmode = session('pmode');
            $firstname = session('firstname');
            $lastname = session('lastname');
            $others = session('others');
            $course = session('course');
            $app_no = session('app_no');

            return view('onlineapplication.preview', compact('ptype', 'pmode', 'firstname', 'lastname', 'others', 'course', 'app_no'));
        }else{
            return redirect()->route('login');
        }
    	
    	
    	
    }
    public function store()
    {
        if(session()->has('app_no') )
        {
    	$pwd = Str::upper(session('lastname'));
    	$users = new User;
    	$users->name = session('firstname').' '.session('others').' '.session('lastname');
    	$users->app_no = session('app_no');
    	$users->phone = session('phone');
    	$users->email = session('email');
    	$users->ptype = session('ptype');
    	$users->pmode = session('pmode');
    	$users->course = session('course');
    	$users->session = '2020/2021';
    	$users->password = Hash::make($pwd);
    	$users->status = 0;
        $users->role = 2;
    	
    	$users->save();
    	
        session(['reg' => 'reg']);
    	return redirect()->route('payment');
        }else{
            return redirect()->route('login');
        }
    }
    public function payment()
    {
        if(session()->has('reg') )
        {
    	   return view('onlineapplication.payment');
        }else{
            return redirect()->route('login');
        }
    }
}
