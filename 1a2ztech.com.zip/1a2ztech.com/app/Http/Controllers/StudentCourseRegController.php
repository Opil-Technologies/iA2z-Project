<?php

namespace App\Http\Controllers;

use Auth;
use App\Academic;
use App\Allocate;
use App\Course_Reg;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class StudentCourseRegController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'student', 'biodata']);
    }

    public function index()
    {
        $academic = Academic::whereStatus(1)->first();
    	$coursereg = Allocate::where(['semester' => $academic->semester, 'level' => Auth::user()->ptype.'-1', 'department_id' => Auth::user()->course])->get();
    	return view('students.course.index', compact('coursereg'));
    }

    public function edit()
    {
        $academic = Academic::whereStatus(1)->first();
        $coursereg = Allocate::where(['semester' => $academic->semester, 'level' => Auth::user()->ptype.'-1', 'department_id' => Auth::user()->course])->get();
        $creg = Course_Reg::where(['student_id' => Auth::user()->id, 'academic' => $academic->id])->first();
        return view('students.course.edit', compact('coursereg', 'creg'));
    }

    public function store(Request $request)
    {
        $academic = Academic::whereStatus(1)->first();
        $ad = '';

    	foreach ($request->cr as $key => $value) {
    		$ad = $ad.$value.',';
    	}

            $cr = new Course_Reg;
            $cr->student_id = Auth::user()->id;
            $cr->allocate_id = $ad;
            $cr->academic = $academic->id;
            $cr->status = 0;

            $cr->save();

            Session::flash('type', 'success');
            Session::flash('message', 'Course succesfully Registered!!');
    	    return redirect()->route('student-dashboard');
    }

    public function update(Request $request)
    {
        $academic = Academic::whereStatus(1)->first();
        $ad = '';

        foreach ($request->cr as $key => $value) {
            $ad = $ad.$value.',';
        }
            $update = Course_Reg::where(['student_id' => Auth::user()->id, 'academic' => $academic->id])->first();
            $update->allocate_id = $ad;

            $update->save();
            Session::flash('type', 'success');
            Session::flash('message', 'Course Registration Updated!!');
            return redirect()->back();
    }
    public function docket()
    {
        $academic = Academic::whereStatus(1)->first();
        $cr = Course_Reg::where(['student_id' => Auth::user()->id, 'academic' => $academic->id])->first();
        $ecr = explode(',', $cr->allocate_id);
        $docket = [];
        foreach ($ecr as $key => $value) {
            array_push($docket, Allocate::whereId($value)->first());
        }
        $docket = (object) $docket;


        return view('students.course.docket', compact('docket'));
    }
}
