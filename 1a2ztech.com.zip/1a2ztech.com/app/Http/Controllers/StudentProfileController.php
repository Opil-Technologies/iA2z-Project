<?php

namespace App\Http\Controllers;

use Auth;
use App\Profile;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class StudentProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware(['auth', 'student']);
    }
    public function index()
    {
        if(Auth::user()->status == 1)
            {
                return redirect()->route('student-dashboard');
            }

        return view('students.profile.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $biodata = new Profile;
        $biodata->user_id = Auth::user()->id;
        $biodata->address = $request->address;
        $biodata->religion = $request->religion;
        $biodata->gender = $request->gender;
        $biodata->dob = $request->dob;
        $biodata->genotype = $request->genotype;
        $biodata->status = 0;
        
        $biodata->save();
        
        $status = User::find(Auth::user()->id);
        $status->status = 1;
        
        $status->save();

        Session::flash('type', 'success');
        Session::flash('message', 'Registration succesfully Completed!!');
        return redirect()->route('student-dashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $bd = Profile::where('user_id', Auth::user()->id)->firstOrFail();
        return view('students.profile.edit', compact('bd'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $bioupdate = Profile::where('user_id', $id)->firstOrFail();
        $bioupdate->address = $request->address;
        $bioupdate->religion = $request->religion;
        $bioupdate->gender = $request->gender;
        $bioupdate->dob = $request->dob;
        $bioupdate->genotype = $request->genotype;
        
        $bioupdate->save();
        
        Session::flash('type', 'success');
        Session::flash('message', 'Bio-data succesfully Updated!!');
        return redirect()->route('student-dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
