<?php

namespace App\Http\Middleware;

use Auth;
use App\Academic;
use App\Course_Reg;
use Illuminate\Support\Facades\Session;
use Closure;

class CourseReg
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $ac = Academic::whereStatus(1)->first();
        $cr = Course_Reg::where(['student_id' => Auth::user()->id, 'academic' => $ac->id])->exists();
            if($cr)
            {
                session::flash('message', 'You have previously Register your Courses');
                session::flash('type', 'default');
                return redirect()->route('student-dashboard');
            }
        return $next($request);
    }
}
