<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allocate extends Model
{
	protected $fillable = [
        'course_unit', 'course_id', 'semester', 'department_id', 'level', 'remark', 'status',
    ];
    public function department()
    {
    	return $this->belongsTo('App\Department');
    }
    public function course()
    {
    	return $this->belongsTo('App\Course', 'course_id', 'slug');
    }
}
