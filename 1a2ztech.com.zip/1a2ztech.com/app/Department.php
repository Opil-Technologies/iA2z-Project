<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    public function allocates()
    {
    	return $this->hasMany('App\Allocate');
    }
    public function users()
    {
    	return $this->hasMany('App\User');
    }

}
