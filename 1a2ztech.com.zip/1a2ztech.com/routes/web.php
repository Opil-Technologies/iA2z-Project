<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/admin/course/allocate', function () {
    return view('admin/course/allocate');
});

Auth::routes(['register' => false]);

/*
		APPLICATION ROUTES ARE DECLARED HERE
*/ 

Route::get('/onlineapplication', 'OnlineApplicationController@index')->name('apply');
Route::post('/onlineapplication', 'OnlineApplicationController@capture')->name('apply-save');
Route::get('/onlineapplication/store', 'OnlineApplicationController@store')->name('app_store');
Route::get('/onlineapplication/preview', 'OnlineApplicationController@preview')->name('preview');
Route::get('/onlineapplication/payment', 'OnlineApplicationController@payment')->name('payment');


/*
		ADMIN ROUTES ARE DECLARED HERE
*/ 
Route::get('/admin/dashboard', 'AdminDashboardController@index')->name('admin-dashboard');
Route::get('/admin/course', 'AdminCourseController@index')->name('admin-course');
Route::post('/admin/course', 'AdminCourseController@store')->name('admin-store');
Route::get('/admin/course/allocate/{id}', 'AdminCourseController@allocate')->name('admin-allocate');
Route::post('/admin/course/allocate', 'AdminCourseController@allocate_store')->name('admin-allocate-store');
Route::get('/admin/courseform', 'AdminCourseController@courseform')->name('admin-courseform');
Route::get('/fetch/allocate/{id}', 'AdminCourseController@fetchAllocated');
Route::delete('/delete/allocate/{id}', 'AdminCourseController@deleteAllocated');
Route::delete('/delete/course/{id}', 'AdminCourseController@deleteCourse');
Route::get('/fetch/dept', 'AdminCourseController@fetchDept');
Route::get('/fetch/course', 'AdminCourseController@courselist');

/*
		STUDENT ROUTES ARE DECLARED HERE
*/ 
Route::get('/student/dashboard', 'StudentDashboardController@index')->name('student-dashboard');
Route::get('/student/course-reg', 'StudentCourseRegController@index')->name('student-coursereg')->middleware('cr');
Route::get('/student/course-reg/edit', 'StudentCourseRegController@edit')->name('student-coursereg-edit');
Route::post('/student/course-reg/edit', 'StudentCourseRegController@update')->name('student-coursereg-update');
Route::post('/student/course-reg', 'StudentCourseRegController@store')->name('student-coursereg-store');

Route::resource('/student/biodata', 'StudentProfileController')->names([
	'index' => 'student-profile'
]);
Route::get('/student/docket', 'StudentCourseRegController@docket')->name('student-docket');
