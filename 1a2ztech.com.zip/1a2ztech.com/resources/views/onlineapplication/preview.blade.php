<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/dashboard/images/favicon.png') }}">
    <title>ia2z School Management System</title>
    <link href="{{ asset('assets/dashboard/css/style.min.css') }}" rel="stylesheet">
    <style>
        .previews{
            font-size: 0.8em;
        }
        td{
            text-transform: uppercase;
        }
    </style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon -->
                        <b class="logo-icon">
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span class="logo-text">
                             <img src="{{ asset('assets/dashboard/images/logo-text.png') }}" alt="Home" /></span>
                        </span>
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Personal</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span class="hide-menu">Dashboard </span></a>
                        </li>
                        
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>

        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title">School Management System (SMS)</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Preview</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    
                </div>
            </div>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                
                <!-- Row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card print">
                            <div class="card-header bg-white">
                                <h4 class="card-title text-danger">PLEASE ENSURE TO PRINT THESE PAGE OR TAKE NOTE OF YOUR APPLICATION NUMBER BEFORE GOING AHEAD TO PAY.</h4>
                            </div>
                            <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-striped table-bordered no-wrap">
                                                            
                                                            <tbody class="previews">
                                                                <tr>
                                                                    <td style="font-family: arial black">STUDENT'S NAME</td>
                                                                    <td>
                                                                        {{ $firstname." ".$others." ".$lastname }}
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">APPLICATION NO</td>
                                                                    <td class="text-danger">
                                                                        {{ $app_no }}
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">DATE APPLIED</td>
                                                                    <td>{{ date('Y-m-d H:i:m') }}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">AMOUNT</td>
                                                                    <td>&#8358<span>15000</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">SCHOOL</td>
                                                                    <td>SCIENCE AND TECHNOLOGY</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">PROGRAM TYPE</td>
                                                                    <td>{{ $ptype }}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">PROGRAM/COURSE</td>
                                                                    <td>{{ $course }}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="font-family: arial black">ACADEMICE SESSION</td>
                                                                    <td>2020/2021</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-12">
                                                    <div class="text-left">
                                                        <a href="{{ route('app_store') }}" class="btn btn-danger" type="submit"> Proceed to payment </a>
                                                        <a href="javascript::void(0)" class="btn btn-info print-page" id="print" type="button"> <span><i class="fa fa-print"></i> Print</span> </a>
                                                        <a href="{{ route('apply') }}" class="btn btn-warning text-white" type="submit"> <span><i class="fa fa-arrow-left"></i> Go Back </span> </a>
                                                    </div>
                                              </div>
                        </div>
                    </div>
                </div>
                <!-- End Row -->
               
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->

            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer">
                   © 2020 iA2z School
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- customizer Panel -->

    <div class="chat-windows"></div>
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->

   
    <script src="{{ asset('assets/dashboard/js/libs/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="{{ asset('assets/dashboard/js/libs/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <!-- apps -->
    <script src="{{ asset('assets/dashboard/js/app.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/app.init.horizontal.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/app-style-switcher.horizontal.js') }}"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="{{ asset('assets/dashboard/js/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
    <!--Wave Effects -->
    <script src="{{ asset('assets/dashboard/js/waves.js') }}"></script>
    <!--Menu sidebar -->
    <script src="{{ asset('assets/dashboard/js/sidebarmenu.js') }}"></script>
    <!--Custom JavaScript -->
    <script src="{{ asset('assets/dashboard/js/feather.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/custom.min.js') }}"></script>
    <!-- ############################################################### -->
    <script>
        $('#print').click(function(){
            $('.print').show();
            window.print();
        })
    </script>
    
</body>
</html>