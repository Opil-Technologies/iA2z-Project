<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/dashboard/images/favicon.png') }}">
    <!-- Custom CSS -->
    <link href="{{ asset('assets/dashboard/css/style.min.css') }}" rel="stylesheet">
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="">
                        <!-- Logo icon -->
                        <b class="logo-icon">
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <img src="{{ asset('assets/dashboard/images/logo-icon.png') }}" alt="homepage" class="dark-logo" />
                            <!-- Light Logo icon -->
                            <img src="{{ asset('assets/dashboard/images/logo-text.png') }}" alt="Home" /></span>
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span class="logo-text">
                             <!-- dark Logo text -->
                             <img src="{{ asset('assets/dashboard/images/logo-text.png') }}" alt="homepage" class="dark-logo" />
                        </span>
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar">
            
        </aside>

        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title">School Management System (SMS)</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Online Application</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                
                <!-- Row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card ">
                            <div class="card-header bg-info">
                                <h4 class="card-title text-white">Online Application 2020/2021</h4>
                            </div>
                            <form action="{{ route('apply-save') }}" method="post" class="form-horizontal">
                                @csrf
                                <div class="form-body">
                                    <div class="card-body">
                                        <h6 class="card-subtitle">Welcome!!.. Please fill the below registration form to apply for the 2020/2021 Integrated A2z School Admission.</h6>
                                        <h4 class="card-title">Input Information</h4>
                                    </div>
                                    <hr class="mt-0 mb-5">
                                    <div class="card-body">
                                        @if(count($errors) > 0)
                                           <div style="background-color: red; color: #fff; padding: 10px; border-radius: 5px; margin: 10px" data-notify="container">
                                              <span data-notify="message">
                                                @foreach($errors->all() as $error)
                                                     <li><strong>{{ $error }}</strong></li>
                                                @endforeach
                                              </span>
                                          </div>
                                       @endif
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><b>PROGRAM TYPE</b></label>
                                                        <select class="form-control custom-select" name="ptype" required="">
                                                            <option selected disabled="">--select--</option>
                                                            <option value="HND">Higher National Diploma</option>
                                                            <option value="ND">National Diploma</option>
                                                        </select>
                                                        <small class="form-control-feedback"> Select program type. </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><b>PROGRAM MODE</b></label>
                                                        <select class="form-control custom-select" name="pmode" required="">
                                                            <option selected disabled="">--select--</option>
                                                            <option value="Full-Time">FullTime</option>
                                                            <option value="Part-Time" disabled="">Part-Time</option>
                                                        </select>
                                                        <small class="form-control-feedback"> Select program mode. </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><b>SELECT COURSE</b></label>
                                                        <select class="form-control custom-select" name="course" required="">
                                                            <option selected disabled="">--select--</option>
                                                            @foreach($dept as $depts)

                                                                <option style="text-transform: uppercase;" value="{{ $depts->id }}">{{ $depts->name }}</option>

                                                            @endforeach
                                                        </select>
                                                        <small class="form-control-feedback"> Select your course. </small>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/row-->
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><b>FIRST NAME</b></label>
                                                        <input type="text" class="form-control" name="firstname" required="">
                                                        <small class="form-control-feedback"> Input your Firstname </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><strong>LAST NAME</strong></label>
                                                        <input type="text" class="form-control" required="" name="lastname">
                                                        <small class="form-control-feedback"> Input you Surname </small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><strong>OTHER NAMES</strong></label>
                                                        <input type="text" class="form-control" name="others" required="">
                                                        <small class="form-control-feedback"> Input your middle name </small>
                                                </div>
                                            </div>
                                        </div>
                                        <!--row-->
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><strong>MOBILE PHONE</strong></label>
                                                        <input type="text" class="form-control" name="phone" required="">
                                                        <small class="form-control-feedback"> Input your phone number </small>
                                                </div>
                                            </div>
                                            <!--/span-->
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="control-label text-right"><strong>EMAIL ADDRESS</strong></label>
                                                        <input type="email" class="form-control" name="email" required="">
                                                        <small class="form-control-feedback"> Input your email </small>
                                                </div>
                                            </div>
                                            <!--/span-->
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="form-actions">
                                        <div class="card-body">
                                            <div class="text-right">
                                                <button type="submit" class="btn btn-info">Apply</button>
                                                </form>
                                                <button type="button" class="btn btn-dark">Clear</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>
                    </div>
                </div>
                <!-- End Row -->
               
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->

            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer">
                   © 2020 Monster Admin by wrappixel.com
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- customizer Panel -->

    <div class="chat-windows"></div>
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->

    <script src="{{ asset('assets/dashboard/js/libs/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="{{ asset('assets/dashboard/js/libs/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <!-- apps -->
    <script src="{{ asset('assets/dashboard/js/app.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/app.init.horizontal.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/app-style-switcher.horizontal.js') }}"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="{{ asset('assets/dashboard/js/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
    <!--Wave Effects -->
    <script src="{{ asset('assets/dashboard/js/waves.js') }}"></script>
    <!--Menu sidebar -->
    <script src="{{ asset('assets/dashboard/js/sidebarmenu.js') }}"></script>
    <!--Custom JavaScript -->
    <script src="{{ asset('assets/dashboard/js/feather.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/custom.min.js') }}"></script>
    <!-- ############################################################### -->
    
    
</body>
</html>