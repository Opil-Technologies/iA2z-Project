<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/dashboard/images/favicon.png') }}">
    <title>iA2z School Login</title>
    <link href="{{ asset('assets/dashboard/js/libs/sweetalert2/dist/sweetalert2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/dashboard/css/style.min.css') }}" rel="stylesheet">
   
</head>

<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center" style="background:url({{ asset('assets/dashboard/images/background/login-register.jpg') }}) no-repeat top center;">
            <div class="auth-box on-sidebar p-4 bg-white m-0">
                <div id="loginform">
                    <div class="logo text-center">
                            <img src="{{ asset('assets/dashboard/images/logo-text.png') }}" alt="Home" /></span>
                    </div>
                    <!-- Form -->
                    <div class="row">
                        <div class="col-12">
                            @if(count($errors) > 0)
                                           <div style="background-color: red; color: #fff; padding: 10px; border-radius: 5px; margin: 10px" data-notify="container">
                                              <span data-notify="message">
                                                @foreach($errors->all() as $error)
                                                     <li><strong>{{ $error }}</strong></li>
                                                @endforeach
                                              </span>
                                          </div>
                                       @endif
                            <form class="form-horizontal mt-3 form-material" id="loginform" action="{{ route('login') }}" method="post">
                                @csrf
                                <div class="form-group mb-3">
                                    <div class="col-xs-12">
                                        <input class="form-control" type="text" required="" placeholder="Username e.g GTS-0000" @if(session()->has('reg')) value="{{ session('app_no') }}" @endif name="app_no"> </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="col-xs-12">
                                        <input class="form-control" type="password" required="" placeholder="Surname as password" name="password"> </div>
                                </div>
                                <div class="form-group d-flex align-items-center">
                                    <div class="checkbox checkbox-info float-left pt-0 pl-1 ml-3 mb-3">
                                        <input id="checkbox-signup" type="checkbox">
                                        <label for="checkbox-signup"> Remember me </label>
                                    </div> 
                                    <a href="javascript:void(0)" id="to-recover" class="text-dark ml-auto mb-3"><i class="fa fa-lock mr-1"></i> Forgot pwd?</a> 
                                </div>
                                <div class="form-group text-center mt-3">
                                    <div class="col-xs-12">
                                        <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Log In</button>
                                    </div>
                                </div>
                                <div class="form-group mb-0">
                                    <div class="col-sm-12 text-center">
                                        <p>Don't have an account? <a href="authentication-register1.html" class="text-info font-weight-normal ml-1">Sign Up</a></p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div id="recoverform">
                    <div class="logo">
                        <h3 class="font-weight-medium mb-3">Recover Password</h3>
                        <span>Enter your Email and instructions will be sent to you!</span>
                    </div>
                    <div class="row mt-3">
                        <!-- Form -->
                        <form class="col-12" action="https://www.wrappixel.com/demos/admin-templates/monster-bootstrap-latest/monster/src/main/index.html">
                            <!-- email -->
                            <div class="form-group row">
                                <div class="col-12">
                                    <input class="form-control" type="email" required="" placeholder="Username">
                                </div>
                            </div>
                            <!-- pwd -->
                            <div class="row mt-3">
                                <div class="col-12">
                                    <button class="btn btn-block btn-lg btn-primary text-uppercase" type="submit" name="action">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper scss in scafholding.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper scss in scafholding.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right Sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right Sidebar -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- All Required js -->
    <!-- ============================================================== -->
    <script src="{{ asset('assets/dashboard/js/libs/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="{{ asset('assets/dashboard/js/libs/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/sweetalert2/dist/sweetalert2.all.min.js') }}"></script>
    <!-- ============================================================== -->
    <!-- This page plugin js -->
    <!-- ============================================================== -->
    <script>
    $('[data-toggle="tooltip"]').tooltip();
    $(".preloader").fadeOut();
    // ============================================================== 
    // Login and Recover Password 
    // ============================================================== 
    $('#to-recover').on("click", function() {
        $("#loginform").slideUp();
        $("#recoverform").fadeIn();
    });
    </script>

    @if(session()->has('reg'))

        <script>
        !function ($) {
            "use strict";

            var SweetAlert = function () { };
            SweetAlert.prototype.init = function () {
            setTimeout(function(){
                Swal.fire("Payment Successful!", "You have successfully complete your online application. You can now Login with your Application Number.", "success")
            }, 2000);
        } 
                $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert

        }(window.jQuery),

            //initializing 
            function ($) {
                "use strict";
                $.SweetAlert.init()
            }(window.jQuery);
                
            </script>

            {{ session()->forget('reg') }}

    @endif
    
</body>
</html>