<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/dashboard/images/favicon.png') }}">
    <title>Welcome to 1a2zSchool Mg Sys</title>
    <!-- Custom CSS -->
    <link href="{{ asset('assets/dashboard/css/style.min.css') }}" rel="stylesheet">
</head>

<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <div class="error-box">
            <div class="error-body text-center">
                <img src="{{ asset('assets/dashboard/images/logo-text.png') }}">
                <div class="mt-4">
                    <h3>1a2ztech School Mg. System</h3>
                    <h5 class="mb-0 text-danger font-weight-medium">2020/2021 Admission is ongoing. Apply Now!!!</h5>
                    <h5 class="text-danger font-weight-medium">Online Application</h5>
                </div>
                <div class="mt-4"><i class="ti-settings font-24"></i></div>
                <div class="mt-4">
                    @if (Route::has('login'))
                        @auth
                            <a href="" class="btn btn-md btn-primary">Home</a>
                        @else
                            <a href="{{ url('/onlineapplication') }}" class="btn btn-md btn-success">Apply Here Now!!</a>
                            <a href="{{ route('login') }}" class="btn btn-md btn-info">Login to Portal</a>
                        @endauth
                    @endif

                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- All Required js -->
    <!-- ============================================================== -->
    <script src="{{ asset('assets/dashboard/js/libs/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/popper.js/dist/umd/popper.min.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script>
    $('[data-toggle="tooltip"]').tooltip();
    $(".preloader").fadeOut();
    </script>
</body>
</html>

