@extends('layouts.engine')
@section('content')
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h3 class="page-title">Dashboard</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-7 d-flex justify-content-end align-self-center d-none d-md-flex">
                        <div class="d-flex">
                            <div class="dropdown mr-2 hidden-sm-down">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="mdi mdi-plus-circle"></i> Current Session </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="#">2020/2021 Session</a></div>
                            </div>
                            <button class="btn btn-secondary"><i class="mdi mdi-plus-circle"></i>New Session</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Courses</h4>
                                <div class="text-right">
                                    <h2 class="font-weight-light mb-0"><i class="ti-arrow-up text-success"></i> {{ $courses }}</h2>
                                    <span class="text-muted">Available</span>
                                </div>
                                <span class="text-success">100%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 100%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Departments</h4>
                                <div class="text-right">
                                    <h2 class="font-weight-light mb-0"><i class="ti-arrow-up text-info"></i> {{ $dept }}</h2>
                                    <span class="text-muted">Available</span>
                                </div>
                                <span class="text-info">30%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 30%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Students</h4>
                                <div class="text-right">
                                    <h2 class="font-weight-light mb-0"><i class="ti-arrow-up text-purple"></i> {{ $profile }}</h2>
                                    <span class="text-muted">Registered</span>
                                </div>
                                <span class="text-purple">20%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: 20%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Session</h4>
                                <div class="text-right">
                                    <h2 class="font-weight-light mb-0"><i class="ti-arrow-down text-danger"></i> 2020/2021</h2>
                                    <span class="text-muted">Academic Session</span>
                                </div>
                                <span class="text-danger">100%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: 100%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-md-flex no-block">
                                    <h4 class="card-title">Recently Registered</h4>
                                </div>
                                <div class="table-responsive mt-2">
                                    <table class="table stylish-table mb-0 mt-2 no-wrap v-middle">
                                        <thead>
                                            <tr>
                                                <th class="font-weight-normal text-muted border-0 border-bottom">Assigned</th>
                                                <th class="font-weight-normal text-muted border-0 border-bottom">Name</th>
                                                <th class="font-weight-normal text-muted border-0 border-bottom">Department</th>
                                                <th class="font-weight-normal text-muted border-0 border-bottom">Program Type</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($student as $students)
                                                <tr>
                                                    <td style="width:50px; text-transform: uppercase;">
                                                        <span class="round rounded-circle text-white d-inline-block text-center bg-info">
                                                            @php

                                                            echo    substr($students->name, 0, 1)

                                                            @endphp
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <h6 class="font-weight-medium mb-0 nowrap" style="text-transform: capitalize;">{{ $students->name }}
                                                        </h6>
                                                        <small class="text-muted no-wrap">{{ $students->app_no }}
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <h6 style="text-transform: capitalize;">{{ $students->department->name }}</h6>
                                                    </td>
                                                    <td>{{ $students->ptype }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="alert alert-primary bg-info text-white border-0" role="alert">
                                    <strong>Hint - </strong> Please remember to Allocate course after they are added.
                                </div>
                                <div class="alert alert-info bg-info text-white border-0" role="alert">
                                    <strong>Hint - </strong> Register courses and allocate them to departments!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
@endsection