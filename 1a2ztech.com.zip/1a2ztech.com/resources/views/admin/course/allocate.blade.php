@extends('layouts.engine')
@section('style')

    <link href="{{ asset('assets/dashboard/js/libs/footable/css/footable.bootstrap.min.css') }}" rel="stylesheet">

@endsection
@section('content')

    <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title" style="text-transform: capitalize;">{{ $course->course_title.'('.$course->course_code.')'}}</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item">Course</li>
                                    <li class="breadcrumb-item active" aria-current="page">Allocate</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-7 d-flex justify-content-end align-self-center d-none d-md-flex">
                        <div class="d-flex">
                            <div class="dropdown mr-2 hidden-sm-down">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="mdi mdi-plus-circle"></i> Current Session </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="#">2020/2021 Session</a></div>
                            </div>
                            <button class="btn btn-secondary"><i class="mdi mdi-plus-circle"></i>New Session</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">please click allocate button to allocate {{ $course->course_code}} </h4>
                                <allocate-component :id="'{!! $cid !!}'"></allocate-component>
                                {{-- <div class="d-flex align-items-center justify-content-end">
                                    
                                    <button type="button" class="btn btn-info btn-rounded m-t-10 mb-2 "
                                    data-toggle="modal" data-target="#add-contact">Allocate Course</button>
                                </div>
                                <!-- Add Contact Popup Model -->
                                <div id="add-contact" class="modal fade in" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header d-flex align-items-center">
                                                <h4 class="modal-title" id="myModalLabel">Add New Course</h4>
                                                <button type="button" class="close ml-auto" data-dismiss="modal"
                                                    aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="post" action="{{ route('admin-allocate-store') }}">
                                                    @csrf
                                                    <input type="hidden" id="course_id" value="{{ $cid }}" name="course_id">
                                                    <div class="form-group">
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="dept" required id="dept">
                                                                <option> select--department</option>
                                                                @foreach($dept as $depts)
                                                                    <option value="{{$depts->id}}">{{ $depts->name }}</option>
                                                                @endforeach
                                                            </select> 
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="level" required id="level">
                                                                <option> select--level</option>
                                                                <option value="HND-2">HND-2</option>
                                                                <option value="HND-1">HND-1</option>
                                                                <option value="ND-2">ND-2</option>
                                                                <option value="ND-1">ND-1</option>
                                                            </select> 
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="semester" required id="semester">
                                                                <option> select--semester</option>
                                                                <option value="1ST">1ST</option>
                                                                <option value="2ND">2ND</option>
                                                            </select> 
                                                        </div>
                                                        
                                                        <div class="col-md-12 m-b-20">
                                                            <input type="number" class="form-control" placeholder="Course Unit" name="course_unit" required id="course_unit">
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="remark" required id="remark">
                                                                <option> select--remark</option>
                                                                <option>Compulsory</option>
                                                                <option>Optional</option>
                                                            </select> 
                                                        </div>
                                                    </div>
                                                
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-info waves-effect" id="btn-submit">Save</button>
                                                <button type="button" class="btn btn-default waves-effect"
                                                    data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                        </form>
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <div class="table-responsive">
                                    <table id="demo-foo-addrow"
                                        class="table table-bordered m-t-30 table-hover contact-list no-wrap" data-paging="true"
                                        data-paging-size="7">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Department</th>
                                                <th>Level</th>
                                                <th>Semester</th>
                                                <th>Course Unit</th>
                                                <th>Remark</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($allocate as $allocates)

                                                <tr>
                                                    <td>{{$loop->iteration}}</td>
                                                    <td>
                                                        {{ $allocates->department->name }}
                                                    </td>
                                                    <td>{{ $allocates->level }}</td>
                                                    <td>
                                                        {{ $allocates->semester }}
                                                    </td>
                                                    <td>
                                                        {{ $allocates->course_unit }}
                                                    </td>
                                                    <td>
                                                        @if($allocates->remark == 'compulsory')
                                                        <span class="badge py-1 badge-warning">{{ $allocates->remark }}</span>
                                                        @else
                                                            <span class="badge py-1 badge-success">{{ $allocates->remark }}</span>

                                                        @endif
                                                        
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-info">Edit</button>
                                                        <button class="btn btn-sm btn-danger">Delete</button>
                                                    </td>
                                                </tr>

                                            @endforeach
                                        </tbody>
                                    </table>
                                </div> --}}
                            </div>
                            
                        </div>
                        <!-- Column -->
                    </div>
                </div>
            </div>

@endsection
@section('scripts')

    <script src="{{ asset('assets/dashboard/js/libs/moment/moment.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/footable/js/footable.min.js') }}"></script>
    <script>
        $('#clickme').click(function(){
            $('#add-contact').modal('hide');
        })
    </script>
@endsection
