@extends('layouts.engine')
@section('style')

    <link href="{{ asset('assets/dashboard/js/libs/footable/css/footable.bootstrap.min.css') }}" rel="stylesheet">

@endsection
@section('content')

    <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title">Courses</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Course</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-7 d-flex justify-content-end align-self-center d-none d-md-flex">
                        <div class="d-flex">
                            <div class="dropdown mr-2 hidden-sm-down">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="mdi mdi-plus-circle"></i> Current Session </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="#">2020/2021 Session</a></div>
                            </div>
                            <button class="btn btn-secondary"><i class="mdi mdi-plus-circle"></i>New Session</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">List of Course (Click to allocate courses)</h4>

                                <course-component></course-component>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
            </div>

@endsection
@section('scripts')

    <script src="{{ asset('assets/dashboard/js/libs/moment/moment.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/libs/footable/js/footable.min.js') }}"></script>

@endsection











