@extends('layouts.engine')
@section('style')

    <link rel="stylesheet" href="{{ asset('assets/dashboard/js/taskboard/css/lobilist.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/dashboard/js/taskboard/css/jquery-ui.min.css') }}">

@endsection
@section('content')
            <div class="invoice-application">
                <!-- Left Part -->
                <div class="left-part bg-white fixed-left-part list-of-user">
                            <!-- Mobile toggle button -->
                            <a class="ti-menu ti-close btn btn-success show-left-part d-block d-md-none" href="javascript:void(0)"></a>
                            <!-- Mobile toggle button -->
                          <div class="p-3">
                                <h4>Chat Sidebar</h4>
                          </div>
                            <div class="scrollable position-relative" style="height:100%;">
                                <div class="p-3 border-bottom">
                                        <h5 class="card-title">Search Invoice</h5>
                                        <form>
                                            <div class="searchbar">
                                                <input class="form-control" type="text" placeholder="Search Invoice">
                                            </div>
                                        </form>
                                </div>
                                <ul class="mailbox list-style-none app-invoice">
                                        <li>
                                            <div class="message-center chat-scroll invoice-users">
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 active listing-user" id="invoice-123" data-invoice-id="123">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-success btn-circle"><i class="mdi mdi-face"></i></button>
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Shraddha Chhatraliya</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #123</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 9 Fab 2020</span> 
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-124" data-invoice-id="124">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-danger btn-circle"><i class="mdi mdi-face"></i></button>
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Nirav Joshi</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #124</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 21 Fab 2019</span>    
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-125" data-invoice-id="125">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-warning btn-circle"><i class="mdi mdi-face"></i></button> 
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Sunil Joshi</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #125</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 21 Jan 2019</span>    
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-126" data-invoice-id="126">
                                                        <span class="user-img position-relative d-inline-block">
                                                            <button class="btn btn-primary btn-circle"><i class="mdi mdi-face"></i></button>    
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Vishank Joshi</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #126</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 15 Mar 2019</span>   
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-127" data-invoice-id="127">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-info btn-circle"><i class="mdi mdi-face"></i></button>       
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Virat Kohali</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #127</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 19 Oct 2020</span>     
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user"id="invoice-128" data-invoice-id="128">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-success btn-circle"><i class="mdi mdi-face"></i></button>          
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Smith John</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #128</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 21 Oct 2020</span>    
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-129" data-invoice-id="129">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-dark btn-circle"><i class="mdi mdi-face"></i></button>    
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Sachin Emily</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #129</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 29 Mar 2020</span>       
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                                <!-- Message -->
                                                <a href="javascript:void(0)" class="invoice-user message-item align-items-center border-bottom px-3 py-2 listing-user" id="invoice-130" data-invoice-id="130">
                                                        <span class="user-img position-relative d-inline-block"> 
                                                            <button class="btn btn-dark btn-circle"><i class="mdi mdi-face"></i></button>    
                                                        </span>
                                                        <div class="mail-contnet w-75 d-inline-block v-middle pl-2">
                                                            <h5 class="message-title mb-0 mt-1 text-truncate invoice-customer">To: Stiphan Robots</h5> 
                                                            <span class="font-12 text-nowrap d-block text-muted text-truncate invoice-id"><span class="font-weight-bold text-dark">Id:</span> #130</span> 
                                                            <span class="font-12 text-nowrap d-block text-muted invoice-date"><span class="font-weight-bold text-dark">Date:</span> 31 Mar 2020</span>      
                                                        </div>
                                                </a>
                                                <!-- Message -->
                                            </div>
                                        </li>
                                </ul>
                            </div>
                </div>
                <!-- ./Left part -->
                <!-- Right Part -->
                <div class="right-part invoice-box">
                    <div class="p-4 invoice-inner-part">
                        <div class="chat-not-selected">
                            <div class="text-center">
                                <span class="display-5 text-info"><i class="mdi mdi-file-document-box"></i></span>
                                <h5>Open Invoice from the list</h5>
                            </div>
                        </div>
                        <div class="invoiceing-box">
                            <div class="card card-body">
                                <div class="invoice-header d-flex align-items-center border-bottom pb-3">
                                    <h3 class="font-medium text-uppercase mb-0">Invoice</h3>
                                <div class="ml-auto">
                                    <h4 class="invoice-number"></h4>
                                </div>
                            </div>
                            <div class="" id="custom-invoice">
                                <!-- (1) -->
                                <div class="invoice-123" id="printableArea">
                                    <div class="row pt-3">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="33404756455673545e525a5f1d505c5e">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Shraddha Chhatraliya,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div>  <!-- ./(1) -->
                                <!-- (2) -->
                                <div class="invoice-124" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="99eaedfceffcd9fef4f8f0f5b7faf6f4">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Nirav Joshi,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(2)-->
                                <!-- (3) -->
                                <div class="invoice-125" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="30434455465570575d51595c1e535f5d">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Sunil Joshi,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(3)-->
                                <!-- (4) -->
                                <div class="invoice-126" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="0f7c7b6a796a4f68626e6663216c6062">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Vishank Joshi,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(4)-->
                                <!-- (5) -->
                                <div class="invoice-127" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="740700110211341319151d185a171b19">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Virat Kohali,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(5)-->
                                <!-- (6) -->
                                <div class="invoice-128" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="dfacabbaa9ba9fb8b2beb6b3f1bcb0b2">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Smith John,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(6)-->
                                <!-- (7) -->
                                <div class="invoice-129" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="9fecebfae9fadff8f2fef6f3b1fcf0f2">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Sachin Emily,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(7)-->
                                <!-- (8) -->
                                <div class="invoice-130" id="printableArea">
                                    <div class="row pt-3 printableArea">
                                              <div class="col-md-12">
                                                    <div class="pull-left">
                                                        <address>
                                                            <h3>&nbsp;From,</h3>
                                                            <h4 class="mb-0 font-weight-bold">&nbsp;Steve Jobs</h4>
                                                            <div class="mb-2">
                                                                <span class="font-weight-bold ml-1">Invoice Id:</span><span class="invoice-number ml-2"></span>
                                                                <h6 class="text-muted font-medium">&nbsp;Email: <a href="https://www.wrappixel.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="493a3d2c3f2c092e24282025672a2624">[email&#160;protected]</a></h6>
                                                            </div>
                                                            <p class="text-muted ml-1">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                        </address>
                                                    </div>
                                                    <div class="pull-right text-right">
                                                        <address>
                                                            <h3>To,</h3>
                                                            <h4 class="font-bold">Stiphan Robots,</h4>
                                                            <p class="text-muted ml-4">E 104, Dharti-2,
                                                                <br/> Nr' Viswakarma Temple,
                                                                <br/> Talaja Road,
                                                                <br/> Bhavnagar - 364002</p>
                                                            <p class="mt-4"><b>Invoice Date :</b> <i class="fa fa-calendar"></i> 23rd Jan 2018</p>
                                                            <p><b>Due Date :</b> <i class="fa fa-calendar"></i> 25th Jan 2018</p>
                                                        </address>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="table-responsive mt-5" style="clear: both;">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th>Description</th>
                                                                    <th class="text-right">Quantity</th>
                                                                    <th class="text-right">Unit Cost</th>
                                                                    <th class="text-right">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="text-center">1</td>
                                                                    <td>Milk Powder</td>
                                                                    <td class="text-right">2 </td>
                                                                    <td class="text-right"> $24 </td>
                                                                    <td class="text-right"> $48 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">2</td>
                                                                    <td>Air Conditioner</td>
                                                                    <td class="text-right"> 3 </td>
                                                                    <td class="text-right"> $500 </td>
                                                                    <td class="text-right"> $1500 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">3</td>
                                                                    <td>RC Cars</td>
                                                                    <td class="text-right"> 20 </td>
                                                                    <td class="text-right"> %600 </td>
                                                                    <td class="text-right"> $12000 </td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">4</td>
                                                                    <td>Down Coat</td>
                                                                    <td class="text-right"> 60 </td>
                                                                    <td class="text-right">$5 </td>
                                                                    <td class="text-right"> $300 </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                              </div>
                                              <div class="col-md-12">
                                                    <div class="pull-right mt-4 text-right">
                                                        <p>Sub - Total amount: $13,848</p>
                                                        <p>vat (10%) : $138 </p>
                                                        <hr>
                                                        <h3><b>Total :</b> $13,986</h3>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <hr>
                                                    <div class="text-right">
                                                        <button class="btn btn-danger" type="submit"> Proceed to payment </button>
                                                        <button class="btn btn-default print-page" type="button"> <span><i class="fa fa-print"></i> Print</span> </button>
                                                    </div>
                                              </div>
                                        </div>
                                </div> <!-- ./(8)-->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ./Right Part -->
               </div>
            </div>
@endsection
@section('scripts')          
    <!-- ============================================================== -->
    <script src="{{ asset('assets/dashboard/js/taskboard/js/jquery.ui.touch-punch-improved.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/taskboard/js/jquery-ui.min.js') }}"></script>
        <!-- Bootstrap tether Core JavaScript -->
    <script src="{{ asset('assets/dashboard/js/pages/samplepages/jquery.PrintArea.js') }}"></script>
    <script src="{{ asset('assets/dashboard/js/pages/invoice/invoice.js') }}"></script>

@endsection