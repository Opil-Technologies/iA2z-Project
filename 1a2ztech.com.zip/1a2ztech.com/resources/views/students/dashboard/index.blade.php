@extends('layouts.engine')
@section('content')
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h3 class="page-title">Dashboard</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- Row -->
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-md-flex no-block">
                                    <h4 class="card-title">Student Details</h4>
                                </div>
                                <div class="table-responsive mt-2">
                                    <table class="table stylish-table mb-0 mt-2 no-wrap v-middle">
                                        <tbody>
                                            <tr class="active has-arrow">
                                                <td>

                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> Student Name</h6></td>
                                                <td style="text-transform: uppercase;">
                                                    {{ Auth::user()->name }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> Application no</h6></td>
                                                <td style="text-transform: uppercase;">
                                                    {{ Auth::user()->app_no }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> School</h6></td>
                                                <td style="text-transform: uppercase;">SCIENCE AND TECHNOLOGY</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> Programme</h6></td>
                                                <td style="text-transform: uppercase;">
                                                    {{ Auth::user()->ptype }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> Department</h6></td>
                                                <td style="text-transform: uppercase;">
                                                    {{ $detail->department->name }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h6 class="font-weight-medium mb-0 nowrap"><i class="fas fa-long-arrow-alt-right"></i> Level</h6></td>
                                                <td style="text-transform: uppercase;">{{ Auth::user()->ptype.'-1 '.Auth::user()->pmode }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="alert alert-danger bg-danger text-white border-0" role="alert">
                                    <strong>Warning - </strong> Course Registeration Closes Soon!
                                </div>
                                <div class="alert alert-success" role="alert">
                                    <h4 class="alert-heading">Notice Board!</h4>
                                    <p>Proceed to the Admin block for you facial capturing and biometrics. Make sure to submit all necessary documents on time.</p>
                                    <hr>
                                    <p class="mb-0">Study hard.. Best of Luck!!.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
@endsection
@section('scripts')

    @include('partials.alert')

@endsection