@extends('layouts.engine')
@section('content')
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title">Update Bio-data</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item">Bio-Data</li>
                                    <li class="breadcrumb-item active" aria-current="page">Edit Bio-data</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Student Register</h4>
                                <h6 class="card-subtitle">You have registered, but you can still ulter.</h6>
                            </div>
                            <hr class="mt-0">
                            <form class="form-horizontal striped-rows b-form" method="post" action="{{ url('student/biodata', $bd->user_id) }}">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <h4 class="card-title">Personal Info</h4>
                                    
                                    <div class="form-group row border-bottom mb-0 py-3 bg-light">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Name</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="inputEmail3" placeholder="Last Name Here" disabled="" value="{{ Auth::user()->name }}">
                                        </div>
                                    </div>
                                    <div class="form-group row border-bottom mb-0 py-3">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Email</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="email" class="form-control" id="inputEmail3" placeholder="Email Here" disabled="" value="{{ Auth::user()->email }}">
                                        </div>
                                    </div>
                                    <div class="form-group row mb-0 py-3 bg-light">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Contact No</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="inputEmail3" placeholder="Contact No Here" disabled="" value="{{ Auth::user()->phone }}">
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="card-body">
                                    <h4 class="card-title">Other Info</h4>
                                    <div class="form-group row border-bottom mb-0 py-3">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Address</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Home Address" required="" value="{{ $bd->address }}" name="address">
                                        </div>
                                    </div>
                                    <div class="form-group row border-bottom mb-0 py-3 bg-light">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Religion</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <select class="form-control" required="" name="religion">
                                                <option @if($bd->religion == 'Christain') selected @endif value="Christain">Christain</option>
                                                <option @if($bd->religion == 'Muslim') selected @endif value="Muslim">Muslim</option>
                                                <option @if($bd->religion == 'Traditional') selected @endif value="Traditional">Traditional</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row border-bottom mb-0 py-3 bg-light">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Gender</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <select class="form-control" required="" name="gender">
                                                
                                                <option @if($bd->gender == 'Male') selected @endif value="Male">Male</option>
                                                <option @if($bd->gender == 'Female') selected @endif value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-0 py-3">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Date of Birth</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <input type="date" max="2004-01-31" min="1990-01-31" class="form-control" id="inputEmail3" placeholder="About Project Here" required="" value="{{ $bd->dob }}" name="dob">
                                        </div>
                                    </div>
                                    <div class="form-group row border-bottom mb-0 py-3">
                                        <div class="col-sm-3">
                                            <div class="d-flex align-items-center justify-content-end">
                                                <label for="inputEmail3" class="control-label col-form-label">Genotype</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-9">
                                            <select class="form-control" required="" name="genotype">
                                                <option @if($bd->genotype == 'AA') selected @endif value="AA">AA</option>
                                                <option @if($bd->genotype == 'AS') selected @endif value="AS">AS</option>
                                                <option @if($bd->genotype == 'SS') selected @endif value="SS">SS</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="card-body">
                                    <div class="form-group mb-0 text-right">
                                        <button type="submit" class="btn btn-info waves-effect waves-light">Save</button>
                                        <button type="submit" class="btn btn-dark waves-effect waves-light">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End Row -->
                
            </div>

@endsection