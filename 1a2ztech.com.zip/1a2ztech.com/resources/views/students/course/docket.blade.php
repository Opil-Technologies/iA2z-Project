<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8" />
        <title>Integrated A2z School</title>

    
<link href="../assets/css/schedule.css" rel="stylesheet" />
<link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.css" />
<style type="text/css">
    body{
        font-family: 'Rajdhani', sans-serif;
        font-size: 12px;
        background-size:10%;
    }
    /*table, ,  {
        
    }*/
    .main td{
        border: 1px solid #060;
    }
    .main th{
        border: 1px solid #060;
        background-color: #060;
        color:#fff;
    }

    .bio_print{
        color:#006600;
        font-size: 14px;
        /*padding: 5px 5px;*/
    }
    .padding-left{
        padding-left:10px;
        font-weight:bold;
        font-size: 17px;
    }
    .padding-right{
        padding-right:10px;
        font-weight:bold;
        font-size: 17px;
    }
    .text-code{
        margin-top:10px;
        color:#000;
        font-weight:bold;
        font-size: 20px;
        text-align:center;
    }
    .picture{
        text-align:right;
    }
    .docket-header{
        color:#fff;
        font-size: 22px;
        text-align:center;
        font-weight:bold;
        background-color: unset;
        box-shadow: inset 0 0 0 1000px #006600;
    }
    blockquote.emph {
        padding: 10px 10px;
        margin: 0px 0px 0px;
        font-size: 17.5px;
        color:#006600;
        border-left:10px solid #006600;
        border-left-color: #006600;
    }
    @media print {
        /* style sheet for print goes here */
        .noprint {
            visibility: hidden;
        }

        .courses{
            color:darkblue;
        font-size: 12px;
        text-align:center;
        font-weight:300;
        }
       
    }

    .rotate2{ /*leaning left <- */
        -webkit-transform:rotate(270deg);
        -moz-transform:rotate(270deg);
        -o-transform:rotate(270deg);
        -ms-transform:rotate(270deg);
        transform:rotate(270deg);
    }
    .rotate4{ /*upside down*/
        -webkit-transform:rotate(180deg);
        -moz-transform:rotate(180deg);
        -o-transform:rotate(180deg);
        -ms-transform:rotate(180deg);
        transform:rotate(180deg);
        font-weight:bold;
        font-size: 15px;
    }
    .rotate6{ /*leaning right -> */
        -webkit-transform:rotate(90deg);
        -moz-transform:rotate(90deg);
        -o-transform:rotate(90deg);
        -ms-transform:rotate(90deg);
        transform:rotate(90deg);
    }
    .rotate8{ /*vertical flip*/ /*upside-down mirror*/
        -moz-transform: scale(1, -1);
        -webkit-transform: scale(1, -1);
        -o-transform: scale(1, -1);
        -ms-transform: scale(1, -1);
        transform: scale(1, -1);
    }
    .rotate10{ /*vertical flip*/ /*upside-down*/
        -moz-transform: rotate(90deg) scale(1, -1);
        -webkit-transform: rotate(90deg) scale(1, -1);
        -o-transform: rotate(90deg) scale(1, -1);
        -ms-transform: rotate(90deg) scale(1, -1);
        transform: rotate(90deg) scale(1, -1);
    }
    .rotate12{ /*horizontal flip*/ /*left-right mirror*/
        -moz-transform: scale(-1, 1);
        -webkit-transform: scale(-1, 1);
        -o-transform: scale(-1, 1);
        -ms-transform: scale(-1, 1);
        transform: scale(-1, 1);
    }
    .rotate14{ /*horizontal flip*/ /*left-right mirror*/
        -moz-transform: rotate(90deg) scale(-1, 1);
        -webkit-transform: rotate(90deg) scale(-1, 1);
        -o-transform: rotate(90deg) scale(-1, 1);
        -ms-transform: rotate(90deg) scale(-1, 1);
        transform: rotate(90deg) scale(-1, 1);
    }
      .p5 {
        padding: 5px;
    }

     .p6 {
        float:right;
    }

    .page {
        width: 21cm;
        min-height: 20cm;
        padding: 0.5cm;
        margin: 1cm auto;
        border: 1px #D3D3D3 solid;
        border-radius: 5px;
        background: transparent;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
    .back{
        background-image: url(../assets/images/wmgb.png);
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }

    @page {
        /*size: A4;*/
        margin: 0;
    }
    @media print {
        .page {
            margin: 0;
            border: initial;
            border-radius: initial;
            width:inherit;
            max-height: 20cm;
            box-shadow: initial;
            background: initial;
            /*page-break-after: always;*/
        }
    }

</style>

</head>
<body>
    
        

    <div class="vertical-align-wrap">
        <div class="vertical-align-middle">
            <div class="content">
                     <form method="post" action="./CourseRegistrationDetails" id="ctl00">
                <div>
                    <div class="panel-body">
                      
                        <div>

                            <div class="page">
                                <table style="width: 800px; border: 0px; margin-bottom: 3px;" align="center" id="printDiv">
                                    <tbody>
                                        <tr>
                                            <td align="left" style="border: 0px; padding-left: 50px;">
                                                <img src="{{ asset('assets/dashboard/images/logo-text.png') }}" alt="iA2z Logo" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table style="width: 100%; border: 0px; margin-bottom: 0px; margin-top: 0px;" align="center" id="printDiv">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="docket-header back">
                                                    COURSE REGISTRATION FORM
                                                </div>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="back">
                                    <table style="width: 100%; border: 0px; margin-bottom: 0px; margin-top: 0px; padding-right: 5px;" align="center" id="printDiv">
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <table>
                                                        <tbody>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>MATRIC NUMBER:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblMatricnum">18010231036</span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>NAME:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblName">OJOMO PAUL ILESANMI</span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>LEVEL:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblLevelname">HND II FULL TIME</span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>SEMESTER:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblSemester">SECOND SEMESTER</span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>ACADEMIC SESSION:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblSessionName">2019/2020</span>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>SCHOOL:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblSchoolName">SCIENCE AND TECHNOLOGY</span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="bio_print">
                                                                    <b>PROGRAMME:</b>
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblProgramme">HND COMPUTER SCIENCE FULL TIME</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                                <td valign="right">
                                                    <table align="right">
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <img id="ContentPlaceHolder1_Passport" src="../ImageCSharp.aspx?StdImageID=GTS1811564" align="middle" style="height:120px;width:120px;" />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td valign="center">
                                                                    <h2 class="text-code">
                                                                        &nbsp;
                                                                    </h2>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table border="0" cellpadding="0" cellspacing="0" class="courses">
                                        
                                        <tr id="ContentPlaceHolder1_gridviewpart1">
	<td>
                                                <div>
		<table cellspacing="0" rules="all" border="1" id="ContentPlaceHolder1_GridView1" style="font-size:15px;font-weight:bold;width:780px;border-collapse:collapse;">
			<tr>
				<th class="gridviewheader" align="center" valign="middle" scope="col">S/N</th><th class="gridviewheader" align="center" valign="middle" scope="col">Course Title</th><th class="gridviewheader" align="center" valign="middle" scope="col">Course Code</th><th class="gridviewheader" align="center" valign="middle" scope="col">Course Unit</th><th class="gridviewheader" align="center" valign="middle" scope="col">Remark</th>
			</tr>
            @foreach($docket as $dockets)
                    <tr>
                        <td align="center" valign="middle"> 1 </td>
                        <td align="center" valign="middle">{{ $dockets->id }}</td>
                        <td align="center" valign="middle">COM 421</td>
                        <td align="center" valign="middle">3</td>
                        <td align="center" valign="middle">C</td>
                    </tr>
            @endforeach
            
            
		</table>
	</div>
                                            </td>
</tr>


                                        <tr>
                                            <td>
                                                <table>
                                                        <tbody>
                                                            <tr>
                                                                <td class="bio_print">
                                                                     Total Registered Unit(s) :
                                                                </td>
                                                                <td class="padding-left">
                                                                    <span id="ContentPlaceHolder1_LblTotalCUnit">22</span>
                                                                </td>
                                                                <td  class="bio_print" style="align: right;">
                                                                    Maximum Allowed Unit(s) :
                                                                </td>
                                                                <td class="padding-right">
                                                                    <span id="ContentPlaceHolder1_LblMaxCUnit">33</span>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                </table>

                                            </td>
                                        </tr>
                                    </table>

                                    <br/>
                                    <table style="width: 100%; border: 0px; margin-bottom: 0px; margin-top: 0px; padding-right: 5px;" align="center" id="printDiv">
                                        <tbody>
                                            <tr>
                                                <td class="p5 padding-right"><br /> ______________________<br />Class Adviser/HOD</td>
                                                <td class="p5"></td>
                                                <td class="p6 padding-right"><br /> ______________________<br />School Officer</td>
                                            </tr>
                                            <tr>
                                                <td class="p5 bio_print">
                                                    <b>DATE SUBMITTED:</b> &nbsp;  
                                                    <span id="ContentPlaceHolder1_LblDateSubmitted" class="padding-left">07 Jun 2020</span>

                                                </td>
                                                <td class="p5"></td>
                                                <td class="p6 bio_print">
                                                    <b>DATE PRINTED:</b>
                                                    <span id="ContentPlaceHolder1_LblDatePrinted" class="padding-left">7/19/2020</span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                         </form>
            </div>
        </div>

    </div>




</body>
</html>