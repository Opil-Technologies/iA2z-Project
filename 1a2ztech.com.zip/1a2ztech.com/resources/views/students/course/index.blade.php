@extends('layouts.engine')
@section('content')
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-md-5 align-self-center">
                        <h4 class="page-title">Course Registration</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Course Reg</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                @if($coursereg->isEmpty())
                                    <h3 style="font-family: arial">Course Registration Not Available</h3 style="font-family: arial">
                                    @else
                                    <h4 class="card-title">Register Your Courses</h4>
                                
                                <div class="table-responsive">
                                    <table id="demo-foo-addrow"
                                        class="table table-bordered m-t-30 table-hover contact-list no-wrap" data-paging="true"
                                        data-paging-size="7">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <input type="checkbox" id="checkAll">
                                                </th>
                                                <th>Course Title</th>
                                                <th>Course Code</th>
                                                <th>Course Unit</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <form method="post" action="{{ route('student-coursereg-store') }}"> 
                                            @csrf
                                            @foreach($coursereg as $course_regs)

                                                <tr>
                                                    <td>
                                                        <input type="checkbox" name="cr[]" value="{{ $course_regs->id }}">
                                                    </td>
                                                    <td>
                                                        {{ $course_regs->course->course_title }}
                                                    </td>
                                                    <td>
                                                        {{ $course_regs->course->course_code }}
                                                    </td>
                                                    <td>
                                                        {{ $course_regs->course_unit }}
                                                    </td>
                                                    <td>
                                                        {{ $course_regs->remark }}
                                                    </td>
                                                </tr>

                                            @endforeach
                                        </tbody>
                                    </table>
                                    <div class="col-md-12">
                                                    <div class="text-left">
                                                        <button class="btn btn-primary" type="submit"> Register Courses </button>
                                                        </form>
                                                        <a href="javascript::void(0)" class="btn btn-success text-white" id="uncheck" type="submit"> <span><i class="fas fa-undo"></i> Reset </span> </a>
                                                    </div>
                                              </div>

                                </div>

                                @endif


                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
@endsection
@section('scripts')

    <script>
        $('#uncheck').click(function(){
            $('input:checkbox').not(this).prop('checked', false);
        })
        $('#checkAll').click(function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
        })
    </script>

@endsection