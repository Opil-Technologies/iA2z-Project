@if(session()->has('message'))

<script>
	!function ($) {
            "use strict";

            var SweetAlert = function () { };
            SweetAlert.prototype.init = function () {
    Swal.fire({
                position: 'top-end',
                type: '{{ session('type') }}',
                title: '{{ session('message') }}',
                showConfirmButton: false,
                timer: 4000
            })
   } 
                $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert

        }(window.jQuery),

            //initializing 
            function ($) {
                "use strict";
                $.SweetAlert.init()
            }(window.jQuery);
</script>



@endif
