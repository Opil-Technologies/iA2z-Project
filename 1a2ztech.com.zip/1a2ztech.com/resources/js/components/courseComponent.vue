<template>
	<div>
		<vue-snotify></vue-snotify>
		<div class="d-flex align-items-center justify-content-end">
                       <button type="button" class="btn btn-info btn-rounded m-t-10 mb-2 "
                                    data-toggle="modal" data-target="#add-contact">Add New Course</button>
                                </div>
                                	<!-- Add Contact Popup Model -->
                                <div id="add-contact" class="modal fade in" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header d-flex align-items-center">
                                                <h4 class="modal-title" id="myModalLabel">Add New Course</h4>
                                                <button type="button" class="close ml-auto" data-dismiss="modal"
                                                    aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                            	<div class="alert alert-success alert-dismissible fade show" v-if="showAlert">
                                            		New Course Added Successfully. Click on close box or add more course.
                                            		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            			<span aria-hidden="true">&times;</span>
                                            		</button>
                                            	</div>
                                                <form class="form-horizontal form-material">
                                                    
                                                    <div class="form-group">
                                                        <div class="col-md-12 m-b-20">
                                                            <input type="text" class="form-control"
                                                                placeholder="Course Title" name="course_title" v-model="lists.course_title"> </div>
                                                        
                                                        <div class="col-md-12 m-b-20">
                                                            <input type="text" class="form-control" placeholder="Course Code" v-model="lists.course_code" name="course_code">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-info waves-effect" @click.once="send()">Save</button>
                                                <button type="button" class="btn btn-default waves-effect"
                                                    data-dismiss="modal">Cancel</button>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                
                                <div class="table-responsive">
                                    <table id="demo-foo-addrow"
                                        class="table table-bordered m-t-30 table-hover contact-list no-wrap" data-paging="true"
                                        data-paging-size="7">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Course Title</th>
                                                <th>Course Code</th>
                                                <th>Allocate</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                <tr v-for="(item, key, index) in items">
                                                    <td>{{ ++key }}</td>
                                                    <td>
                                                        {{ item.course_title }}
                                                    </td>
                                                    <td>{{ item.course_code }} </td>
                                                    <td><a :href="'/admin/course/allocate/'+item.slug" class="badge py-1 badge-info">Click here to Allocate Course</a href> </td>
                                                    <td>
                                                        <button @click.prevent="cDelete(item.id)" class="btn btn-sm btn-danger">delete</button>
                                                    </td>
                                                </tr>
                                        </tbody>
                                    </table>
                                </div>
	</div>
</template>
<script>
	
	export default{
		data(){
			return{
				lists:{
					course_title:'',
					course_code:'',
				},
				items:{},
				showAlert: false,
			}
		},
		created(){
			this.fetchc();
		},
		methods:{
			fetchc(){
				var id = this.id;
				axios.get('/fetch/course')
                  .then((response) => this.items = response.data)
                  .catch((error) => this.errors = error.response.data.errors);
			
			},
			cDelete(id, h){
                this.$snotify.prompt('Deleting this will causes damages', 'Delete Course', {
                  buttons: [
                    {text: 'Yes', action: (toast) => {this.deletec(id, toast.id)}, bold: true },
                    {text: 'No', action: (toast) => {this.$snotify.remove(toast.id)}, },
                  ],
                  placeholder: 'Do you still want to continue?'
                });
            },
            deletec(id, h){
				axios.delete(`/delete/course/${id}`)
                  .then((response) => this.notify());
			},
			send()
			{
				axios.post('/admin/course', this.$data.lists)
					.then((response) => this.notifySend())
					.catch((error) => [this.errors = error.response.data.errors, this.reload()]);
			},
			notifySend()
			{
				this.$snotify.success('Course Added successfully!!', 'Success', {
				  timeout: 10000,
				  showProgressBar: true,
				  closeOnClick: true,
				  pauseOnHover: true,
				});
				this.fetchc();
				this.lists.course_code = '';
				this.lists.course_title = '';
				this.showAlert = true;
				setTimeout(() => this.showAlert = false,  7000 );
			},
			notify(h)
			{
				this.$snotify.success('Deleted successfully!!', 'Success', {
				  timeout: 10000,
				  showProgressBar: true,
				  closeOnClick: true,
				  pauseOnHover: true,
				});
				this.fetchc();
				this.$snotify.remove(h);
			},
		}
	}
</script>
<style>
	@import "~vue-snotify/styles/material.css";
</style>