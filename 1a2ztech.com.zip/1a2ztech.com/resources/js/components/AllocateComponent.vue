<template> 
<div>
	<vue-snotify></vue-snotify>
		<div class="d-flex align-items-center justify-content-end">
            <button type="button" class="btn btn-info btn-rounded m-t-10 mb-2 " data-toggle="modal" data-target="#add-contact">Allocate Course
             </button>
        </div>
        <div >
        	<div id="add-contact" class="modal fade in">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header d-flex align-items-center">
                                                <h4 class="modal-title" id="myModalLabel">Add New Course</h4>
                                                <button type="button" class="close ml-auto" data-dismiss="modal"
                                                    aria-hidden="true">×</button>
                                            </div>
                                            <div class="modal-body">
                                            	<div class="alert alert-success alert-dismissible fade show" v-if="showAlert">
                                            		Course Allocated Successfully. Click on close to cancel Box or conitnue allocating.
                                            		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            			<span aria-hidden="true">&times;</span>
                                            		</button>
                                            	</div>
                                                <form class="form-horizontal form-material">
                                                    <ul class="col-lg-12">
                                                    	<li class="text-danger" v-for="error in errors">
                                                    		{{ error[0] }}
                                                    	</li>
                                                    </ul>
                                                    <input type="hidden" id="course_id" value="" name="course_id" >
                                                    <div class="form-group">
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="dept" required id="dept" v-model="lists.dept">
                                                                <option selected=""> select--department</option>
                                                                <option v-for="alldept in alldepts" :value="alldept.id">
                                                                	{{ alldept.name }}
                                                                </option>
                                                                    
                                                                
                                                            </select> 
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="level" required id="level" v-model="lists.level">
                                                                <option > select--level</option>
                                                                <option selected  value="HND-2">HND-2</option>
                                                                <option value="HND-1">HND-1</option>
                                                                <option value="ND-2">ND-2</option>
                                                                <option value="ND-1">ND-1</option>
                                                            </select> 
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="semester" required id="semester" v-model="lists.semester">
                                                                <option> select--semester</option>
                                                                <option value="1ST">1ST</option>
                                                                <option value="2ND">2ND</option>
                                                            </select> 
                                                        </div>
                                                        
                                                        <div class="col-md-12 m-b-20">
                                                            <input type="number" class="form-control" placeholder="Course Unit" v-model="lists.course_unit" required id="course_unit">
                                                        </div>
                                                        <div class="col-md-12 m-b-20">
                                                            <select class="form-control" name="remark" required id="remark" v-model="lists.remark">
                                                                <option> select--remark</option>
                                                                <option value="Compulsory">Compulsory</option>
                                                                <option value="Optional">Optional</option>
                                                            </select> 
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-info waves-effect" id="btn-submit" @click="send()">Save</button>
                                                <button type="button" class="btn btn-default waves-effect"
                                                    data-dismiss="modal" >Cancel</button>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                        
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
        </div>
        
                                <div class="table-responsive">
                                    <table id="demo-foo-addrow"
                                        class="table table-bordered m-t-30 table-hover contact-list no-wrap" data-paging="true"
                                        data-paging-size="7">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Department</th>
                                                <th>Level</th>
                                                <th>Semester</th>
                                                <th>Course Unit</th>
                                                <th>Remark</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                                <tr v-for="(item, key) in items">
                                                    <td>{{ ++key}}</td>
                                                    <td>
                                                        {{ item.department.name }}
                                                    </td>
                                                    <td>{{ item.level }}</td>
                                                    <td>
                                                        {{ item.semester }}
                                                    </td>
                                                    <td>
                                                        {{ item.course_unit }}
                                                    </td>
                                                    <td>
                                                        
                                                         {{ item.remark }} 

                                                        
                                                        
                                                    </td>
                                                    <td>
                                                        <button @click.prevent="cDelete(item.id)" class="btn btn-sm btn-danger">Delete</button>
                                                    </td>
                                                </tr>
                                        </tbody>
                                    </table>
                                    
                                </div>
                                
	
</div>
</template>
<script>
	import VModal from 'vue-js-modal'
	export default{
		props:{
			id:'',
		},
		data(){
			return{
				lists:{
					cid: '',
					dept:'select--department',
					level:'select--level',
					semester:'select--semester',
					course_unit:'',
					remark:'select--remark', 
				},
				items:{},
				alldepts:{},
				errors:{},
				showAlert: false,
				
			}
		},
		created(){
				this.fetchc();
				this.alldept();
			},
		methods:{
			cDelete(id, h){
                this.$snotify.prompt('Deleting this will causes damages', 'Delete Allocated', {
                  buttons: [
                    {text: 'Yes', action: (toast) => {this.deletec(id, toast.id)}, bold: true },
                    {text: 'No', action: (toast) => {this.$snotify.remove(toast.id)}, },
                  ],
                  placeholder: 'Do you want to continue?'
                });
            },
			send()
			{
				if(this.lists.dept == 'select--department')
					this.lists.dept = '';
				if(this.lists.level == 'select--level')
					this.lists.level = '';
				if(this.lists.semester == 'select--semester')
					this.lists.semester = '';
				if(this.lists.remark == 'select--remark')
					this.lists.remark = '';

				this.lists.cid = this.id;
				
				axios.post('/admin/course/allocate', this.$data.lists)
				  .then((response) => this.notifySend())
				  .catch((error) => [this.errors = error.response.data.errors, this.reload()]);
			},
			fetchc(){
				var id = this.id;
				axios.get('/fetch/allocate/'+this.id)
                  .then((response) => this.items = response.data)
                  .catch((error) => this.errors = error.response.data.errors);
			
			},
			alldept(){
				axios.get('/fetch/dept')
                  .then((response) => this.alldepts = response.data)
                  .catch((error) => this.errors = error.response.data.errors);
			
			},
			deletec(id, h){
				axios.delete(`/delete/allocate/${id}`)
                  .then((response) => this.notify());
			},
			notify(h)
			{
				this.$snotify.success('Deleted successfully!!', 'Success', {
				  timeout: 10000,
				  showProgressBar: true,
				  closeOnClick: true,
				  pauseOnHover: true,
				});
				this.fetchc();
				this.$snotify.remove(h);
			},
			notifySend()
			{
				this.$snotify.success('Course Allocated successfully!!', 'Success', {
				  timeout: 10000,
				  showProgressBar: true,
				  closeOnClick: true,
				  pauseOnHover: true,
				});
				this.fetchc();
				this.reload();
				this.showAlert = true;
				setTimeout(() => this.showAlert = false,  7000 );
			},
			reload()
			{
				this.lists.dept = 'select--department';
				this.lists.level = 'select--level';
				this.lists.semester = 'select--semester';
				this.lists.course_unit = '';
				this.lists.remark = 'select--remark';
			}
		},
	}
</script>
<style>
	@import "~vue-snotify/styles/material.css";
</style>