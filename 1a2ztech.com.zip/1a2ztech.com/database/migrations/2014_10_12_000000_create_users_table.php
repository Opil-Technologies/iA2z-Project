<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('app_no')->unique();
            $table->string('phone')->unique();
            $table->string('email')->unique();
            $table->string('ptype');
            $table->string('pmode');
            $table->string('course');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('session');
            $table->string('password');
            $table->boolean('status');
            $table->integer('role');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
