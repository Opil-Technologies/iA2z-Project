-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2020 at 11:36 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ia2ztech`
--

-- --------------------------------------------------------

--
-- Table structure for table `academics`
--

CREATE TABLE `academics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `academics`
--

INSERT INTO `academics` (`id`, `session`, `semester`, `status`, `created_at`, `updated_at`) VALUES
(1, '2020/2021', '1ST', 1, '2020-07-19 05:00:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `allocates`
--

CREATE TABLE `allocates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_unit` int(11) NOT NULL,
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `allocates`
--

INSERT INTO `allocates` (`id`, `course_id`, `department_id`, `level`, `semester`, `course_unit`, `remark`, `status`, `created_at`, `updated_at`) VALUES
(3, 'hSzoZ', '2', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:34:40', '2020-07-19 03:34:40'),
(4, 'hSzoZ', '3', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:35:01', '2020-07-19 03:35:01'),
(5, 'Wu8KE', '3', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:36:40', '2020-07-19 03:36:40'),
(6, 'qpZxR', '1', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:37:24', '2020-07-19 03:37:24'),
(7, 'qpZxR', '2', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:37:44', '2020-07-19 03:37:44'),
(8, 'qpZxR', '3', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:38:15', '2020-07-19 03:38:15'),
(9, 'tNKm2', '1', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:40:19', '2020-07-19 03:40:19'),
(10, 'hR9sd', '1', 'ND-1', '1ST', 1, 'Optional', 0, '2020-07-19 03:40:54', '2020-07-19 03:40:54'),
(11, 'hR9sd', '2', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:41:20', '2020-07-19 03:41:20'),
(12, 'hR9sd', '3', 'ND-1', '1ST', 1, 'Optional', 0, '2020-07-19 03:41:48', '2020-07-19 03:41:48'),
(13, '0j1ei', '1', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:43:23', '2020-07-19 03:43:23'),
(14, '0j1ei', '2', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:44:11', '2020-07-19 03:44:11'),
(15, '0j1ei', '3', 'ND-1', '1ST', 2, 'Compulsory', 0, '2020-07-19 03:46:21', '2020-07-19 03:46:21'),
(16, '5AV1Q', '1', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:47:02', '2020-07-19 03:47:02'),
(17, '5AV1Q', '2', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:47:21', '2020-07-19 03:47:21'),
(18, '5AV1Q', '3', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:48:12', '2020-07-19 03:48:12'),
(19, '8XiYL', '1', 'ND-1', '1ST', 3, 'Compulsory', 0, '2020-07-19 03:48:57', '2020-07-19 03:48:57'),
(23, 'zvnxH', '2', 'ND-2', '1ST', 3, 'Compulsory', 0, '2020-07-20 10:53:20', '2020-07-20 10:53:20'),
(28, 'zvnxH', '1', 'HND-2', '2ND', 3, 'Compulsory', 0, '2020-07-20 11:38:53', '2020-07-20 11:38:53'),
(41, 'zvnxH', '2', 'HND-2', '2ND', 3, 'Compulsory', 0, '2020-07-20 19:35:17', '2020-07-20 19:35:17');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_title`, `course_code`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Introduction to Programming', 'Com 113', '8XiYL', 0, '2020-07-18 21:17:37', '2020-07-18 21:17:37'),
(2, 'Algebra and Geometry', 'MTH 111', '5AV1Q', 0, '2020-07-19 03:03:53', '2020-07-19 03:03:53'),
(3, 'Use of English', 'GNS 111', '0j1ei', 0, '2020-07-19 03:04:43', '2020-07-19 03:04:43'),
(4, 'Use of Library', 'GNS 112', 'hR9sd', 0, '2020-07-19 03:05:26', '2020-07-19 03:05:26'),
(5, 'Digital Electronics', 'Com 112', 'tNKm2', 0, '2020-07-19 03:05:46', '2020-07-19 03:05:46'),
(6, 'Citizenship Education', 'GNS 113', 'qpZxR', 0, '2020-07-19 03:06:35', '2020-07-19 03:06:35'),
(7, 'Introduction to Mechanics', 'EEC 114', 'Wu8KE', 0, '2020-07-19 03:07:28', '2020-07-19 03:07:28'),
(8, 'Technical Drawing', 'CIV 113', 'hSzoZ', 0, '2020-07-19 03:09:00', '2020-07-19 03:09:00'),
(9, 'Introduction to Electricity', 'EEC 111', 'zvnxH', 0, '2020-07-19 03:10:57', '2020-07-19 03:10:57'),
(11, 'Programming in Java', 'Com 211', 'ywqms', 0, '2020-07-20 20:03:21', '2020-07-20 20:03:21');

-- --------------------------------------------------------

--
-- Table structure for table `course__regs`
--

CREATE TABLE `course__regs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `allocate_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course__regs`
--

INSERT INTO `course__regs` (`id`, `student_id`, `allocate_id`, `academic`, `status`, `created_at`, `updated_at`) VALUES
(6, 6, '6,9,10,13,16,19,', '1', 0, '2020-07-19 10:28:37', '2020-07-19 10:28:37'),
(7, 7, '6,9,10,13,16,19,', '1', 0, '2020-07-19 10:40:35', '2020-07-19 10:40:35');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `school` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `school`, `created_at`, `updated_at`) VALUES
(1, 'COMPUTER SCIENCE', 'SCIENCE AND TECHNOLOGY', '2020-07-18 23:25:21', '2020-07-18 23:25:21'),
(2, 'WELDING AND FABRICATION', 'SCHOOL OF ENGINEERING', '2020-07-18 23:26:20', NULL),
(3, 'ELECTRICAL ELECTRONIC', 'SCHOOL OF ENGINERING', '2020-07-18 23:26:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_07_17_105648_create_courses_table', 1),
(5, '2020_07_17_120550_create_allocates_table', 1),
(6, '2020_07_17_125441_create_departments_table', 1),
(7, '2020_07_17_131934_create_course__regs_table', 1),
(8, '2020_07_18_060726_create_profiles_table', 2),
(9, '2020_07_19_034849_create_academics_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `genotype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `address`, `religion`, `gender`, `dob`, `genotype`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 4, '1 Akinola str, Omikunle estate', 'Christain', 'Male', '2004-01-31', 'AA', NULL, '0', '2020-07-18 07:01:55', '2020-07-18 07:01:55'),
(4, 5, '1 Akinola str, Omikunle estate', 'Muslim', 'Male', '2004-01-13', 'AA', NULL, '0', '2020-07-18 19:41:57', '2020-07-18 21:01:15'),
(7, 6, '4531 Maud Street', 'Muslim', 'Male', '2004-01-10', 'AS', NULL, '0', '2020-07-19 10:14:50', '2020-07-19 10:15:57'),
(8, 7, 'isara ogun state', 'Christain', 'Female', '2004-01-23', 'AS', NULL, '0', '2020-07-19 10:32:47', '2020-07-19 10:32:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `app_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ptype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pmode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `session` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `role` int(10) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `app_no`, `phone`, `email`, `ptype`, `pmode`, `course`, `email_verified_at`, `session`, `password`, `status`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'Paul ilesanmi Ojomo', 'Admin', '+2348088840077', 'ojomopaul@gmail.com', '', '', '1', NULL, '', '$2y$10$EsCLhHQYXyStswoMnbzJNOXAUfboR3XDoBzft6KcOFPwuJn7bqG5m', 1, 1, NULL, '2020-07-18 04:55:05', '2020-07-18 04:55:05'),
(5, 'Eloka Dumebi Emmanuel', 'GTS-795893', '09098765458', 'eloka@gmail.com', 'ND', 'Full-Time', '2', NULL, '2020/2021', '$2y$10$YsVE8TtGRtqOvHp6ZzpDPejlHNDNEkpeLuaZBncCLM0WQ5OwdE8tO', 1, 2, NULL, '2020-07-18 18:51:11', '2020-07-18 19:41:57'),
(6, 'Precious joe Ujah', 'GTS-268768', '09087654766', 'ujah@gmail.com', 'ND', 'Full-Time', '1', NULL, '2020/2021', '$2y$10$BNxOU5gdK0Kmv/UBDmoNP.UdQ.asc5iwgvT86pkOnsnvcCJHwO45m', 1, 2, NULL, '2020-07-18 22:01:46', '2020-07-19 10:14:50'),
(7, 'Tolulope Bimpe Mayungbe', 'GTS-856993', '09087654567', 'tolu@gmail.com', 'ND', 'Full-Time', '1', NULL, '2020/2021', '$2y$10$T7mVpluaCZM1dklL..w2UeJExHWfLHq.o0o62t0WZJfjB7UkVo3KK', 1, 2, NULL, '2020-07-19 09:01:26', '2020-07-19 10:32:47'),
(9, 'lanre jude wale', 'GTS-641635', '9897656444', 'jude@gmail.com', 'ND', 'Full-Time', '1', NULL, '2020/2021', '$2y$10$Nvbp9O/dJ0NTNmbYY/fM3.MHUS6lWFE4bI.Gs96xF8RRzEZL7xxdO', 0, 2, NULL, '2020-07-20 20:26:45', '2020-07-20 20:26:45'),
(10, 'Simeon tunde remi', 'GTS-176448', '09076755878', 'remi@gmail.com', 'HND', 'Full-Time', '1', NULL, '2020/2021', '$2y$10$B7Cdki.XNrtmKltcaRd1UucCnH3MvwiWb3lCTWqvyLV6PKdncsJsW', 0, 2, NULL, '2020-07-20 20:29:45', '2020-07-20 20:29:45'),
(11, 'tony teniola okey', 'GTS-984493', '09087656789', 'okey@gmail.com', 'ND', 'Full-Time', '1', NULL, '2020/2021', '$2y$10$vYnu8cTGG.Uqceh5nyL1cuzfIUsYCZklRwEqN96WHqjE5KDPnVaa2', 0, 2, NULL, '2020-07-20 20:34:51', '2020-07-20 20:34:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academics`
--
ALTER TABLE `academics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `academics_session_unique` (`session`);

--
-- Indexes for table `allocates`
--
ALTER TABLE `allocates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course__regs`
--
ALTER TABLE `course__regs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `profiles_user_id_unique` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_app_no_unique` (`app_no`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academics`
--
ALTER TABLE `academics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `allocates`
--
ALTER TABLE `allocates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `course__regs`
--
ALTER TABLE `course__regs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
